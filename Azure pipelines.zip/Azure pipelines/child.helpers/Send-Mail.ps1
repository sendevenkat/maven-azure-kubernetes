[CmdletBinding()]
param (
    [Parameter(Mandatory = $false)]
    [string]$Username="skiisparc.im@pg.com",
    [Parameter(Mandatory = $true)]
    [string]$Password,
    [Parameter(Mandatory = $true)]
    [string]$MailsList,
    [Parameter(Mandatory = $false)]
    [string]$AttachmentPath="git_output.log",
    [Parameter(Mandatory = $true)]
    [string]$MailSubject,
    [Parameter(Mandatory = $true)]
    [string]$MailBody
)
     
    $message = New-Object Net.Mail.MailMessage;
    $message.From = "$Username";
    $message.To.Add($MailsList);
    $message.Subject = "$MailSubject";
    $message.Body = "$MailBody";
    Write-Verbose -Message "Checking for an attachment"
    if ($(Test-Path -Path "$AttachmentPath") -eq $True) {
        Write-Verbose -Message "The attachment is in place, attach it to the letter"
        $attachment = New-Object Net.Mail.Attachment($AttachmentPath);
        $message.Attachments.Add($attachment);
    }
    $smtp = New-Object Net.Mail.SmtpClient("smtp.office365.com", "587");
    $smtp.EnableSSL = $true;
    $smtp.Credentials = New-Object System.Net.NetworkCredential($Username, $Password);
    $smtp.send($message);
    Write-Verbose -Message "Mail Sent"
    if ($(Test-Path -Path "$AttachmentPath") -eq $True) {
        $attachment.Dispose();
    }
