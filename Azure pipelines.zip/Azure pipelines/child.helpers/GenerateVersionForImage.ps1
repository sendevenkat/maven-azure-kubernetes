[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$sourceDirectory
)
$GetSourceFiles = Get-ChildItem -Path $sourceDirectory 
if ($GetSourceFiles.Name -contains "pom.xml") {
    [xml]$pomXml = Get-Content $sourceDirectory/pom.xml
    $pattern = [Regex]::new('\d.\d.\d+')
    $version = $pattern.Matches($pomXml.project.version).value
    $versionMajor = "$("v{0}" -f $version)"
    $version = "$("{0}.{1}.{2}" -f $version,$env:BUILD_BUILDNUMBER, $env:BUILD_BUILDID)"

    $versionDocker = $pomXml.project.version
    $nameService = ($pomXml.project.artifactId + "-"+ $versionDocker +".jar")
    $app_name = $pomXml.project.artifactId
    Write-Verbose "Version for $app_name (maven application) is $version"
    Write-Host "##vso[task.setvariable variable=versionMajor]$versionMajor"
    Write-Host "##vso[task.setvariable variable=versionMajor;isOutput=true]$versionMajor"
    Write-Host "##vso[task.setvariable variable=name_service]$nameService"
}
elseif ($GetSourceFiles.Name -contains "package.json") {
    $version = "$("{0}.{1}" -f $env:BUILD_BUILDNUMBER, $env:BUILD_BUILDID)"
    $app_name = $env:BUILD_DEFINITIONNAME
    Write-Verbose "Version for $app_name (npm application) is $version"
}
Write-Host "##vso[task.setvariable variable=version]$version"
Write-Host "##vso[task.setvariable variable=version;isOutput=true]$version"
Write-Host "##vso[task.setvariable variable=app_name;isOutput=true]$app_name"
Write-Host "##vso[task.setvariable variable=app_name]$app_name"