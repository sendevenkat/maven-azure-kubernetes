[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$Directory
)

Write-Verbose -Message "Define source ARMTemplateFiles directory: $Directory"

$items = Get-ChildItem -Path $Directory -Recurse | Where-Object { $_.Extension -eq ".json" }

foreach($item in $items){
    Write-Verbose "Get content of json file $item"
    $armTemplate = (Get-Content -Path $($item.FullName) -Raw) | ConvertFrom-Json 
    $getIR = $armTemplate.resources | Where-Object { $_.Name -match "SPARC-NonProd-IR" } 
    if ($null -ne $getIR) {
        Write-Verbose "Founded SPARC-NonProd-IR resources in file $($item.Name)"

        $getIR.properties.typeProperties = @{}

        Write-Verbose "Replaced SPARC-NonProd-IR typeProperties in file $($item.Name)"

        $armADFString = $armTemplate | ConvertTo-Json -Depth 50
        $armADFString = $armADFString -replace('\\n','\\n')
        $armADFString = $armADFString -replace('\\"','\\"')
        $armADFString = $armADFString -replace('\\t','\\t')
        $armADFString | 
            ForEach-Object { [System.Text.RegularExpressions.Regex]::Unescape($_) } | 
            Out-File $item
        Write-Verbose "ARM template saved as $item"
    }
}