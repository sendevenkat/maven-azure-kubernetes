[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$Directory,
    [Parameter(Mandatory = $true)]
    [string]$IRNametoReplace,
    [Parameter(Mandatory = $true)]
    [string]$NewIRName
)

Write-Verbose -Message "Define source ARMTemplateFiles directory: $Directory"

$items = Get-ChildItem -Path $Directory -Recurse | Where-Object { $_.Extension -eq ".json" }

foreach($item in $items){
    Write-Verbose "Get content of json file $item"
    $ReplaceIRDefinition = (Get-Content -Path $($item.FullName) -Raw).Replace("$IRNametoReplace","$NewIRName") 
    $ReplaceIRDefinition | Set-Content -Path $($item.FullName)
    $armTemplate = (Get-Content -Path $($item.FullName) -Raw) | ConvertFrom-Json 
    $getIR = $armTemplate.resources | Where-Object { $_.Name -match "$NewIRName" } 
    if ($null -ne $getIR) {
        Write-Verbose "Found $NewIRName resources in file $($item.Name)"
        $getIR.properties.typeProperties = @{}

        Write-Verbose "Replaced $NewIRName typeProperties and IR name in file $($item.Name)"

        $armADFString = $armTemplate | ConvertTo-Json -Depth 50 
        $armADFString = $armADFString -replace('\\n','\\n')
        $armADFString = $armADFString -replace('\\"','\\"')
        $armADFString = $armADFString -replace('\\t','\\t')
        $armADFString | 
            ForEach-Object { [System.Text.RegularExpressions.Regex]::Unescape($_) } | 
            Out-File $item
        Write-Verbose "ARM template saved as $item"
    }
}