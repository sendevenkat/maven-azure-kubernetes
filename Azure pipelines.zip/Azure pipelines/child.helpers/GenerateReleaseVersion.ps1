
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$sourceDirectory,

        [Parameter(Mandatory = $true)]
        [string]$releaseName,

        [Parameter(Mandatory = $true)]
        [string]$nameService
    )

    Write-Verbose "Name service: $nameService"
    Write-Verbose "Name release: $releaseName"
    [xml]$pomXml = Get-Content $sourceDirectory/pom.xml

    if ($nameService -contains "pg-sparc-parent") {
        $projectVersion = $pomXml.project.version 
    }
    if ($nameService -contains "pg-sparc-common") {
        $projectVersion = $pomXml.project.parent.version 
    }

    $currentRevisionPattern = [Regex]::new('\d.\d.\d+')
    $currentRevision = $currentRevisionPattern.Matches($projectVersion).value 

    Write-Verbose "Current revision: $currentRevision"

    $currentRevision = $currentRevision.split(".")
    [array]$currentRevision = foreach($number in $currentRevision ) {
    try {
        [int]::parse($number)
    }
    catch {
        Invoke-Expression -Command $number;
    }
    }
    if ($releaseName -eq "SNAPSHOT") {
        $currentRevision[-1] = $currentRevision[-1] + 1
    }
    $newRevision = $currentRevision -join '.'
    $currentReleasePattern = [Regex]::new('-[a-zA-Z]+')
    $currentRelease = $currentReleasePattern.Matches($projectVersion).value
    $newReleaseVersion = "$("{0}{1}" -f "$newRevision",$currentRelease.replace($currentRelease, "-$releaseName"))"
    Write-Verbose "New release version $newReleaseVersion"
    Write-Host "##vso[task.setvariable variable=newReleaseVersion]$newReleaseVersion"