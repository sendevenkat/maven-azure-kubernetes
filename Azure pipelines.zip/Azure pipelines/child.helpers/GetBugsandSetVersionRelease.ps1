[CmdletBinding()]
param (
    [Parameter(Mandatory = $false)]
    [string]$tag_suffix,

    [Parameter(Mandatory = $false)]
    [string]$System_CollectionUri,

    [Parameter(Mandatory = $false)]
    [string]$System_TeamProject,

    [Parameter(Mandatory = $false)]
    [string]$System_AccessToken,

    [Parameter(Mandatory = $false)]
    [string]$Environment

)
###### Get 2 latest deployment tags
$release= (git tag --sort=-creatordate | Where-Object {$_ -like "*-$tag_suffix"} | Select-Object -First 2)
$previousTag=$release[1]
$latestTag=$release[0]
Write-Verbose "Previous tag:$previousTag and latest tag: $latestTag"
###### Get commit logs between tags
$log = (git log "$previousTag..$latestTag" --pretty=format:"%h%x09%an%x09%ad%x09%s")
###### Select commits which contains Bug or Fix in commit message
$bugs = $log | Where-Object {$_ -match 'Bug' -or 'Fix'}
if ($null -ne $bugs) {
    Write-Verbose "Commits with bugs: $bugs"
    $bugItems = $bugs | Where-Object {$_ -match "(?<=\#)[0-9]+"} | ForEach-Object { $Matches[0] }
    Write-Verbose "Workitem ID of bug items included in release: $bugItems"
    foreach ($WorkItemId in $bugItems){
        $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "user",$System_AccessToken)))
        $headers = @{Authorization=("Basic {0}" -f $base64AuthInfo)}

        $url = $('{0}/{1}/_apis/wit/workitems/{2}?api-version=5.0' -f $System_CollectionUri, $System_TeamProject, $WorkItemId)
        ###### Verify whether the value for the Sparc environment field is set and workitem type
        $json=Invoke-RestMethod -Uri $url -Headers $headers -Method Get -ContentType "application/json; charset=utf-8"
        $workItemType=$json.fields.'System.WorkItemType'
        $sparcEnvironmentValue=$json.fields.'Custom.SPARCEnvironment'
        if ($workItemType -eq "Bug") {
            if ($null -ne $sparcEnvironmentValue){
                Write-Verbose "Value already set to $sparcEnvironmentValue"
                $body = @(
                    [ordered]@{
                        op    = 'add'
                        path  = '/fields/Custom.VersionofRelease'
                        value = [string]$latestTag
                    }
                )| ConvertTo-Json -Depth 100 -Compress
            }
            else {
                $env=$Environment.ToUpper()
                $body = @(
                    [ordered]@{
                        op    = 'add'
                        path  = '/fields/Custom.VersionofRelease'
                        value = [string]$latestTag
                    },
                    [ordered]@{
                        op    = 'add'
                        path  = '/fields/Custom.SPARCEnvironment'
                        value = [string]$env
                    }
                )| ConvertTo-Json -Depth 100 -Compress
            }
            Write-Verbose "Body to patch $body"
            Invoke-RestMethod -Uri $url -Headers $headers -Method PATCH -ContentType "application/json-patch+json; charset=utf-8" -Body "[$body]"    
        }
        else {
            Write-Verbose "Item $WorkItemId is $workItemType, not a Bug"
        }
    }
}
else {
    Write-Verbose "Bugs are not found"
}