[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]$InputReportDirectory,

    [Parameter(Mandatory = $false)]
    [string]$JsonReportName="report.json",

    [Parameter(Mandatory = $false)]
    [string]$OutputHtmlReportPath="gitleaks-report.html"

)

###### Usage in pipeline. EXAMPLE ######
#   - task: PowerShell@2
#     displayName: "Script for converting gitleaks report"
#     inputs:
#         filePath: Path-to-the-script/ConvertGitleaksReport.ps1
#         arguments: -InputReportDirectory "Path-to-the-gitleaks-json-report/" -JsonReportName "report.json" -OutputHtmlReportPath "gitleaks-report.html" -Verbose
#         script: ""
#         showWarnings: true

###### Style for html report ######
$header = @"
<style>
   table {
        font-size: 12px;
        border: 0px;
        font-family: Arial, Helvetica, sans-serif;
    }
    td {
        padding: 4px;
        margin: 0px;
        border: 0;
    }
    th {
        background: #395870;
        background: linear-gradient(#49708f, #293f50);
        color: #fff;
        font-size: 11px;
        text-transform: uppercase;
        padding: 10px 15px;
        vertical-align: middle;
    }
    tbody tr:nth-child(even) {
        background: #f0f0f2;
    }
        #CreationDate {
        font-family: Arial, Helvetica, sans-serif;
        color: #ff3300;
        font-size: 12px;
    }
</style>
"@
Write-Verbose "Report file for convert is $JsonReportName, folder: $InputReportDirectory"

if ($(Test-Path -Path "$InputReportDirectory\$JsonReportName") -eq $True) {
    
    $item=Get-ChildItem -Path "$InputReportDirectory\$JsonReportName"

    ###### Convert report from json ######
    $gitleaks_report = Get-Content -Path $item -Raw | ConvertFrom-Json

    ###### Convert report to html with selected via properties columns and style ######
    Write-Verbose "Convert report file $item to html"
    $gitleaks_report | ConvertTo-Html `
    -Property line,lineNumber,offender,offenderEntropy,commit,repo,rule,commitMessage,file,date,tags `
    -Head $header `
    -Body "Founded Leaks" | `
    Out-File -FilePath "$OutputHtmlReportPath" 
    Write-Verbose "Generated report path is $OutputHtmlReportPath"
    $PublishGitleakReport = "true"
    Write-Host "##vso[task.setvariable variable=PublishGitleakReport]$PublishGitleakReport"

}else{
    Write-Verbose "The report isn't found"
    $PublishGitleakReport = "false"
    Write-Host "##vso[task.setvariable variable=PublishGitleakReport]$PublishGitleakReport"
}