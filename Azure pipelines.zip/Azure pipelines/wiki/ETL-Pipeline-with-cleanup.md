[[_TOC_]]
# 1. Overview

Pipeline stages
1. Get tag for deployment 
2. Prepare services to run ADF pipeline
3. Trigger ADF pipeline and check it's status (Data factory)
4. Microservices deployment
5. Event publisher scale up

The whole process was built using a loop for the list of services provided using the Service List parameter from the root template.
A loop has been added for multiple jobs that need to run in parallel. In the pipeline structure, such tasks are highlighted in green.
# 2. Pipeline structure

![ETL-Process-pipeline](images/ETL-Process-pipeline.png)

# 3. Jobs templates
## 3.1 Get image tag for {{service}} in {{env}}
    Templates:
    1. kubelogin.yml 
    2. image-tag-from-aks.yml
    3. image-tag-from-acr.yml
This job conditionally runs templates. The condition depends on the environment name set using the environments parameter. This means that for the DEV environment we select an image with build.number, which is equal to the latest tag.
Sequence seems like this: 
![Get-image-tag-job](images/get-image-tag-1.png)

## 3.2 Unscale event publisher {{env}}
    Templates:
    1. kubelogin.yml 
    2. scale-service.yml

## 3.3 Disable {{service}} in {{env}}

    Templates:
    1. kubelogin.yml 
    2. get-secrets-from-keyvault.yml
    3. delete-deployment.yml 
    4. cleanDB.yml 
    5. maven-authenticate.yml
    6. liquibase-plugin.yml
    7. etlProcedures.yml

## 3.4 Environment {{env}} for adf

    Templates:
    1. get-secrets-from-keyvault.yml
    2. etlProcedures.yml
    3. adf-pipeline-run.yml

## 3.5 Upgrade {{service}} {{env}} with virtualservice

    Templates:
    1. kubelogin.yml
    2. helm-prepare.yml
    3. helm-upgrade-forfactory.yml

## 3.6 Scale event publisher {{env}}

    Templates:
    1. kubelogin.yml
    2. scale-service.yml