[[_TOC_]]

# 1. Overview
1.1. Each Application or solution repository could have a different number of pipelines, but the general approach is to have a dedicated templates for a specific process.
1.2. The approach to store templates independently gives an opportunity to rapidly create a new Application project or multiple projects CI/CD pipelines by reusing universal templates.

1.3 Pipelines is launched inside docker using container jobs (more details [here](https://docs.microsoft.com/en-us/azure/devops/pipelines/process/container-phases?view=azure-devops)). 
Baseimage is used as the base container for launching tasks: pg-sparc-linux-base-container:latest. It stored in azure container registry in shared resource group. 
At the pg-sparc-devops repository you can find Dockerfile.baseimage that was used to create this image, as well as the push-base-image-acr.yml pipeline for publishing the image to acr, it can be used if necessary to add some dependencies to the base image. If you want to modify the baseimage, please use the pipeline https://dev.azure.com/pg-consumer/SK-II-SPARC/_build?definitionId=14229&_a=summary with the pg-sparc-variable of 504090-dependency-for-maven branch. 


# 2. Repositories
2.1. There are the following repositories that are used by DevOps pipelines:

| Name | Description |
|--|--|
| pg-sparc-devops | Single repository for child and solution CI/CD YAML templates |
| pg-sparc-variables | Repository with root pipelines for all microservices, as well as build and deployment variables |
| pg-sparc-(application name) | Microservice repository with source code |

# 3. Folders structure within repositories

3.1 The "pg-sparc-devops" repository folders:

|  Name | Description  |
|--|--|
| child.build | Job templates for build processes |
| child.deployment | Job templates for deployment processes |
| child.helm-charts | Helm charts for Kubernetes |
| child.helpers | Helper templates, powershell scripts, security config files, to support "main" build and deploy Jobs,  |
| feature.solution | Templates which describe general CI/CD process sequence for specific Application type for feature related environments |
| prod.release | Templates which describe general CI/CD process sequence for specific Application type for prod environments |
| solution.app-cicd | Templates which describe general CI/CD process sequence for specific Application type |
| variables | Global variables for build and deployment process |
| wiki | documents for devops repo |

3.2 The "pg-sparc-variables" repository folders:

| Name | Description |
|--|--|
| global.templates | Stores global templates and helper files, can be changed by developers |
| pg-sparc-(application name) | The root pipeline and variables for each application/service are stored |

