# 1. Overview
1.1. To manage CI/CD processes for applications there are used Azure DevOps multistage YAML pipelines.

1.2. The pipelines designed in a modular three-tier approach:

- Tier 1: The "Main" application CI/CD pipeline which links triggers, global variables, and then calls "Stages" template
- Tier 2: The "Stages" template describes CI/CD stages like build, deploy, integration tests. The "Stages" template calls small "Jobs" templates to execute particular tasks for CI/CD process
- Tier 3: The "Jobs" templates that describe specific Azure DevOps tasks.
1.3. The tiers are shown on the diagram below:

![Application-CICD-processes](images/Application-CICD-processes.png)

1.4. The modular approach provides an ability to manage CI/CD pipelines structure and logic by independent processes because pipeline "Stages" sequence and "Jobs" are stored in a different repository.

1.5. So if it's required to update the pipeline for a particular application it could be done without affecting Application source code repository.

1.6. In addition to that, the provided model is centralized and has good maintainability and scalability.

1.7. The "Stages" and "Jobs" are stored in templates are stored in DevOps project and aligned by their own SDLC and branching strategy.

# 2. Templates

Each Application or solution repository could have a different number of pipelines, but the general approach is to have a dedicated templates for a specific process.

Pipeline is launched inside docker using container jobs (more details [here](https://docs.microsoft.com/en-us/azure/devops/pipelines/process/container-phases?view=azure-devops)). This one is used as the base container for launching tasks: skiisparcacrdev01.azurecr.io/pg-sparc-linux-base-container:latest. 
Also in devops repository you can find Dockerfile.baseimage that was used to create this image, as well as the push-base-image-acr.yml pipeline for publishing the image to acr, it can be used if necessary to add some dependencies to the base Image.

## Pipelines file structure:

![Pipelines file structure](images/Pipelines-file-structure.png)