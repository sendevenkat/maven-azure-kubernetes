[[_TOC_]]

## Deployment templates

### helm-prepare.yml

Template helm-prepare.yml The helm-prepare.yml template performs tasks to prepare for the deployment phase.

Tasks:
1.	Set ms values file with environment variables. (for microservices in the excluded_common_list)
 > This task copies additional values from sparc-$(env).values.yaml file (stored in the pg-sparc-(application name)/deploy/sparc-$(env).values.yaml file in pg-sparc-variables repository) in the folder with helm charts. Then these values will be passed as values when helm upgrade is performed
2.	Set common values file with environment variables. (for microservices not in the excluded_common_list)
 > This task copies additional values from common-sparc.values.yaml file (stored in the global.templates/helm.values/common-sparc.values.yaml file in pg-sparc-variables repository) in the folder with helm charts. Then these values will be passed as values when helm upgrade is performed
3.	Inject helmCharts application and environment values
 > This task replaces the tokens declared as follows: #{variable_name}#, taking the values passed through variables files and variables groups
4. Display tokenized helm charts for specific application

The helm-prepare.yml parameters:

|     Parameter name        |   Type  |      Default value     | Description  |
| :------------------------ | :-----: | :--------------------- | ------------ |
|         helmCharts        | string  |          ''            | [**default**] helmCharts release name |
|  envKubernetesNamespace   | string  |          ''            | [**default**] Kubernetes Namespace |
|        helmtemplate       | string  |  pg-sparc-universal-template | [**default**] Helm template stored in helm chart repository |
|  variablesRepository      | string  |  pg-sparc-variables    | [**default**] Repository with variables |
|  DevopsRepository         | string  |  pg-sparc-devops       | [**default**] Devops repository |
|  excluded_common_list     | object  |  pg-sparc-event-publisher | [**default**] microservices in the excluded_common_list |

### kubelogin.yml

Template kubelogin.yml is used for non-interactive login in azure kubernetes service.

Tasks:
1.	Kubelogin.
 > This task uses AzureCLI and command "kubelogin convert-kubeconfig -l azurecli". This command uses an access token from Azure CLI to log in. The token will be issued against whatever tenant was logged in at the time kubelogin convert-kubeconfig -l azurecli was run. This login option only works with managed AAD in AKS.

### helm-upgrade.yml

Template helm-upgrade.yml performs tasks to upgrade for the deployment phase.

Tasks:
1.	Convert helm charts to kubernetes manifests.
 > This task displays the generated helm template that will be applied when performing helm upgrade
2.  Helm Upgrade


The helm-upgrade.yml parameters:

|     Parameter name        |   Type  |      Default value     | Description  |
| :------------------------ | :-----: | :--------------------- | ------------ |
|         helmCharts        | string  |          ''            | [**default**] helmCharts release name |
|        helmtemplate       | string  |  pg-sparc-universal-template | [**default**] Helm template stored in helm chart repository |
|      DevopsRepository     | string  |  pg-sparc-devops | [**default**] Devops repository |

## Helm chart

A single universal helm chart template is used for all microservices. The template is stored in the pg-sparc-devops repository at the following path: child.help-charts\pg-sparc-universal-template. To assign additional values or change the default values, you can use sparc-$env$.values.yaml (where $env$ is dev,sit, or etc ..) file by adding it to the folder with deployment variables

### Helm Chart files:
    Templates:
    1. _helpers.tpl
    2. deployment.yaml
    3. HPA.yaml
    4. service.yaml
    5. VirtualService.yaml
    6. VirtualServiceDirect.yaml
    Chart.yaml
    values.yaml
    sparc-$env.values.yaml (optional)