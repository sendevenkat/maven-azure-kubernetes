## **DEPLOYMENT TO THE DEV/SIT/UAT/PROD ENVIRONMENT.**

For all services we have enabled auto deployment:

By default after the source code merged to the main branch, the microservice pipeline triggers automatically.

![1.png](../images/1.png)

We integrated approval flow for all environments and all microservices pipelines. It mean that after the build stage will be completed, deployment stage won’t be started while responsible person approve the deployment. (See screenshot)

![2.png](../images/2.png)

To approve deployment to the AKS, you need to open the microservices pipeline with Individual CI Trigger -> Click the **Review** button and then click **Approve**

![3.png](../images/3.png)

If you want mannualy deploy an application to the Kubernetes, you need to select microservice pipeline (all of them stored in a separate folder):

![4.png](../images/4.png)

Click **Run pipeline** --> Click **Run**.

![6.png](../images/6.png)

By default it will run pipeline from the main branch of microservice repository:

![7.png](../images/7.png)