[[_TOC_]]

## Build templates
 
Build Pipeline runs whenever dev team merge a change to the main branch of their repo. It also runs when PR in microservice created but the steps a little bit different. 

![Build_Process](images/Build_Process.png)
### generate-app-version.yml

The Powershell task "Version for the deployment stage" runs the powershell script GenerateVersionForImage.ps1 stored in the child.helpers folder in devops repository.
The script generates a docker image version, set app name from pom file for java application and creates output variables for the deployment stage.

Tasks:
1.	Version for the deployment stage

The generate-app-version.yml parameters:

|     Parameter name        |   Type  |      Default value     | Description  |
| :------------------------ | :-----: | :--------------------- | ------------ |
|     DevopsRepository      | string  |    pg-sparc-devops     | [**default**] Devops repository referenece |

### maven-authenticate.yml

The template process has a single step, with MavenAuthenticate task.
The maven-authenticate.yml parameters:
|     Parameter name        |   Type  |      Default value     | Description  |
| :------------------------ | :-----: | :--------------------- | ------------ |
|   mavenAuthenticateFeed   | boolean |           true         | [**default**] Enable or disable Maven Authentication |
|        artifactsFeeds     | string  |repo.maven.sparc.pg.com | [**default**] Artifacts Feeds. Feed repo in which artifacts are stored and published |

### replace-ms-version-pom.yml

The Powershell task "Replace version in pom file to $(version)", where $(version) is variable generated in generate-app-version.yml template.
This task replace version in pom file.

Tasks:
1.	Replace version in pom file to $(version)

### generate-maven-goal.yml

The Powershell task "Define maven goal for build task" runs the powershell script which is generate maven goal for maven build task (depends on $(Build.Reason) variable)

Tasks:
1.	Define maven goal for build task

### maven-build.yml

The template process has a single step, with 3 tasks which is to run the Maven task.

Tasks:
1.	SonarQubePrepare
2.	Maven Build
3.	SonarQube Publish Report

The maven-build.yml parameters are passed from the pg-sparc-(application name)/build/build-vars.yaml file in pg-sparc-variables repository.

The maven-build.yml parameters:
|     Parameter name        |   Type  |      Default value     | Description  |
| :------------------------ | :-----: | :--------------------- | ------------ |
|     conn_sys_Sonar_Qube   | string  |pg-sparc-sonarqube-prod-sa| [**default**] SonarQube Connection String |
|  enableSonarQubeAnalyze   | boolean |           true         | [**default**] Enable or disable SonarQube Analyze task |
|     app_Sonar_Project     | string  |  pg-sparc-test-service | [**optional**] App Sonar Project Name |
|   app_Sonar_jacoco_path   | string  |target/site/jacoco/jacoco.xml| [**optional**] Path for jacoco test results |
|       mavenPomFile        | string  |         pom.xml        | [**default**] Maven Pom File |
|   mavenAuthenticateFeed   | boolean |           true         | [**default**] Enable or disable Maven Authentication |
|        mavenGoals         | string  | package -Dmaven.test.failure.ignore=true | [**default**] Maven goals |
|       jdk_version         | string  |           1.11         | [**default**] JDK Version |
|       DevopsRepo          | string  |    pg-sparc-devops     | [**default**] Devops repository referenece |

### Gitleaks-scan.yml
Gitleaks is a SAST tool for detecting and preventing hardcoded secrets like passwords, api keys, and tokens in git repos.

Tasks:
1.	Gitleaks scan (bash task)
2.	Gitleaks html report (Convert json report to the html)
3.  Publish Gitleaks html report as artifact

The gitleaks-scan.yml parameters:

|     Parameter name        |   Type  |      Default value     | Description  |
| :------------------------ | :-----: | :--------------------- | ------------ |
|         DevopsRepo        | string  |    pg-sparc-devops     | [**default**] Devops repository referenece |

### replace-tokens.yml

The task replacetokens@3 replace version and application name in Dockerfile for docker-build task. Dockerfile stored in variables repository -> global.templates. We use the same Dockerfile for build for all Java applications.

Tasks:
1.	Set application name in Dockerfile

|     Parameter name        |   Type  |      Default value     | Description  |
| :------------------------ | :-----: | :--------------------- | ------------ |
|         variablesRepository        | string  |    pg-sparc-variables     | [**default**] Variables repository referenece |

### docker-build.yml

Build images to the container registry using Docker registry service connection.

Docker-build Tasks:
1. Login to the ACR (usage the service connection to the container registry);
2. Build an image in the docker

|     Parameter name        |   Type  |      Default value     | Description  |
| :------------------------ | :-----: | :--------------------- | ------------ |
|         variablesRepository        | string  |    pg-sparc-variables     | [**default**] Variables repository referenece |

### jfrog-scan.yml
The Jfrog-scan template allows you to send docker images to the jfrog artifactory and scan them for vulnerabilities using Xray Scan

Tasks:
1. Retag docker image for JFrog
2. Create spec-file for jfrog
3. Replace application name to the spec-file for cleaning up jfrog artifactory
4. Clean up jfrog artifactory
5. Artifactory Docker push
6. Artifactory Publish Build Info
7. Artifactory Xray Scan

### docker-push.yml

Push Docker images to the container registry using Docker registry service connection.

Docker-push Tasks:
1. Push an image to the ACR
2. Logout of ACR

### create-build-tag.yml

When the pipeline is successfully completed, a tag with a version equal to the version from pom (project.version without SNAPSHOT)+$env:BUILD_BUILDNUMBER + $env:BUILD_BUILDID is created in the microservice repository. Tag example: 1.0.1.20220322.5.2268046

This task requires additional permissions to create a tag. And also for checkout step require this option:
persistCredentials: true

![Tag_permissions](images/Tag_permissions.png)
